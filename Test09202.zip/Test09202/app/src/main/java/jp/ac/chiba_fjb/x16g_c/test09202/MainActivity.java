package jp.ac.chiba_fjb.x16g_c.test09202;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity {

    private NumberPicker numPicker0, numPicker1, numPicker2, numPicker3, numPicker4;
    private TextView pickerTextView;

    private String[] figures = new String[5];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView dateText = (TextView) findViewById(R.id.date_id);
        Time time = new Time("Asia/Tokyo");
        time.setToNow();
        String date = time.hour + "時" + time.minute + "分";
        dateText.setText(date);


        pickerTextView = findViewById(R.id.text_view);

        numPicker0 = findViewById(R.id.numPicker0);
        numPicker1 = findViewById(R.id.numPicker1);
        numPicker2 = findViewById(R.id.numPicker2);
        numPicker3 = findViewById(R.id.numPicker3);
        numPicker4 = findViewById(R.id.numPicker4);

        Button pickerButton = findViewById(R.id.button1);

        numPicker0.setMaxValue(9);
        numPicker0.setMinValue(0);

        numPicker1.setMaxValue(9);
        numPicker1.setMinValue(0);

        numPicker2.setMaxValue(9);
        numPicker2.setMinValue(0);

        numPicker3.setMaxValue(9);
        numPicker3.setMinValue(0);

        numPicker4.setMaxValue(9);
        numPicker4.setMinValue(0);


        pickerButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                figures[0] = String.valueOf(numPicker0.getValue());
                figures[1] = String.valueOf(numPicker1.getValue());
                figures[2] = String.valueOf(numPicker2.getValue());
                figures[3] = String.valueOf(numPicker3.getValue());
                figures[4] = String.valueOf(numPicker4.getValue());

                String str = String.format("%s%s%s.%s%s",
                        figures[0], figures[1], figures[2], figures[3], figures[4]);
                Float fig = Float.parseFloat(str);

                pickerTextView.setText(String.valueOf(fig));

            }
        });
    }
}




