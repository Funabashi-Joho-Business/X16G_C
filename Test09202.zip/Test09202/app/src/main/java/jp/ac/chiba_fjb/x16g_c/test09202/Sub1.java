package jp.ac.chiba_fjb.x16g_c.test09202;

import android.app.Dialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.CancellationSignal;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;


public class Sub1 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub1);
Intent data = new Intent();
String funsu = getIntent().getStringExtra("funsu");
String jikan = getIntent().getStringExtra("jikan");

        TextView text1 = (TextView)findViewById(R.id.textView8);
        TextView text2 = (TextView)findViewById(R.id.textView9);
        text1.setText(jikan);
        text2.setText(funsu);

    }
}
